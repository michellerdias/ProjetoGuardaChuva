package com.michelle.microbacias.view;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle
import com.michelle.microbacias.R

import android.os.Bundle;

import com.michelle.microbacias.R;

public class Menu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
    }
}