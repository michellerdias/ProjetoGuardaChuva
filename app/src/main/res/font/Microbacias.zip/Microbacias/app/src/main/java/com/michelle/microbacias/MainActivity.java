package com.michelle.microbacias;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.snackbar.Snackbar;
import com.michelle.microbacias.databinding.ActivityMainBinding;

public class Menu extends AppCompatActivity {
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        binding.btEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = binding.editEmail.getText().toString();
                String senha = binding.editSenha.getText().toString();

                if (email.isEmpty()) {
                    mensagem(view, "Digite seu email.");
                } else if (senha.isEmpty()) {
                    mensagem(view, "Digite a sua senha.");
                } else {
                    navegarPraMenu(email);
                }
            }
        });
    }

    private void mensagem(View view, String mensagem) {
        Snackbar snackbar = Snackbar.make(view, mensagem, Snackbar.LENGTH_LONG);
        snackbar.getView().setBackgroundColor(Color.parseColor("#FF0000"));
        snackbar.setTextColor(Color.parseColor("#FFFFFF"));
        snackbar.show();
    }

    private void navegarPraMenu(String email) {
        Intent intent = new Intent(this, Menu.class);
        intent.putExtra("email", email);
        startActivity(intent);
    }
}